
// material-ui



// ==============================|| MAIN LOGO ||============================== //

const LogoSection = () => {

  return (
    <h1>Stock Exchange</h1>
  );
};


export default LogoSection;
