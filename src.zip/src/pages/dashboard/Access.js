import React from "react";

const Access = () => (
  <div>
    <h2 style={{ textAlign: "center" }}>You dont have access</h2>
  </div>
);
export default Access;
